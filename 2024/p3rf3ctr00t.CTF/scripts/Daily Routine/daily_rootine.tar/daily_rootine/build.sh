#! /bin/bash
docker build -t daily_rootine ./
docker stop daily_rootine 2>/dev/null
docker rm daily_rootine 2>/dev/null
docker run --rm --name daily_rootine -itd -p 5050:5050 daily_rootine
docker inspect daily_rootine | grep '"IPAddress"'
