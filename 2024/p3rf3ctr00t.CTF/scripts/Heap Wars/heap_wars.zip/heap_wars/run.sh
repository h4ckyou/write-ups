#!/bin/bash
docker build -t heapwars-image .
docker run --rm -p 1337:1337 heapwars-image