#! /bin/bash
docker build -t sea_shells ./
docker stop sea_shells 2>/dev/null
docker rm sea_shells 2>/dev/null
docker run --rm --name sea_shells -itd -p 5000:5000 sea_shells

