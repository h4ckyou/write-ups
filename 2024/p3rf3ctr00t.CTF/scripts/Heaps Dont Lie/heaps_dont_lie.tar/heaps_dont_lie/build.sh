#! /bin/bash
docker build -t heaps_dont_lie ./
docker stop heaps_dont_lie 2>/dev/null
docker rm heaps_dont_lie 2>/dev/null
docker run --rm --name heaps_dont_lie -itd -p 5000:5000 heaps_dont_lie
