from Crypto.Util.number import getPrime, long_to_bytes
import random
import sympy.ntheory as nt

def g_prime(bit_length):
    return getPrime(bit_length)

def g_rsa_pair(bit_length):
    p = g_prime(bit_length)
    q = nt.nextprime(p)
    
    x, y = 1337, 5000
    for _ in range(random.randint(x, y)):
        q = nt.nextprime(q)

    N = p * q
    phi_N = (p - 1) * (q - 1)
    e = 65537
    d = pow(e, -1, phi_N)  
    public_key = (N, e)
    private_key = (N, d)
    return public_key, private_key

def enryption(message, public_key):
    N, e = public_key
    pt = btl(message.encode())
    ct = pow(pt, e, N)
    return ct

bit_length = 1024
public_key, _ = g_rsa_pair(bit_length)
msg = "urchinsec{Fake_Flag}"
ciphertext = enryption(msg, public_key)
print(f"n: {public_key[0]}")
print(f"e: {public_key[1]}")
print(f"cipher: {ciphertext}")
