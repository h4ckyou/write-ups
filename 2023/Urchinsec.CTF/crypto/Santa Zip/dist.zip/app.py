from santazip import SantaZip

zip_object = SantaZip("flag.txt", "flag.zip", "testing")
print(zip_object.generate_zip_file())
