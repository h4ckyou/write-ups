from cryptography.fernet import Fernet

key = Fernet.generate_key()
cipher_suite = Fernet(key)

zip_filename = "fernet.zip"
with open(zip_filename, 'rb') as file:
    file_data = file.read()

encrypted_data = cipher_suite.encrypt(file_data)

encrypted_zip_filename = "secret_zip.fzip"
with open(encrypted_zip_filename, 'wb') as encrypted_zip_file:
    encrypted_zip_file.write(encrypted_data)

with open("pew.key", "wb") as key_file:
    key_file.write(key)

