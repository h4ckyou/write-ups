#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void login(int secret) {
	char passkey[32];
	char username[10];
	printf("Enter Username : ");
	scanf("%s", &username);
	printf("\nEnter PassKey : ");
	gets(passkey);
	if (strcmp("admin", username) == 0) {
		if (passkey == 0xcafebabe) {
			system("cat /home/bof_ctf/flag.txt");
		} else {
			printf("I think YOU WANNA FIGHT WITH SANTA");
		}
	} else {
		printf("WRONG PASSWORD");
	}
}

int main(int argc, char* argv[]) {
	login(0xdeadbeef);
	return 0;
}
